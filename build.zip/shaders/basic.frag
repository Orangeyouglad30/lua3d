#version 330 core

in vec3 vertexColor;
in vec2 vertexUV;
in vec3 fragmentPosition;
in vec3 fragmentNormal;

out vec4 finalColor;

uniform vec3 lightDirection;
uniform float lightIntensity;
uniform vec3 lightColor;
uniform vec3 viewPosition;
uniform float shininess;
uniform float specularStrength;
uniform vec3 ambientLightColor;

uniform vec3 diffuseColor;
uniform vec3 ambientColor;
uniform vec3 specularColor;

uniform int hasDiffuseTexture;
uniform sampler2D diffuseTexture;

struct PointLight
{
    vec3 position;
    vec3 color;
    float intensity;

    bool isGlobal;
    bool isPoint;
    bool isSpot;

    float constantAttenuation;
    float linearAttenuation;
    float quadraticAttenuation;
};

const int MAX_POINT_LIGHTS = 8;

uniform int pointLightCount;
uniform PointLight pointLights[MAX_POINT_LIGHTS];

vec3 calculate_directional_diffuse(vec3 normal)
{
    vec3 direction =
        normalize(-lightDirection);

    float amount =
        max(dot(normal, direction), 0.0);

    return lightColor *
           lightIntensity *
           amount;
}

vec3 calculate_directional_specular(
    vec3 normal,
    vec3 view_direction
)
{
    vec3 direction =
        normalize(-lightDirection);

    vec3 halfway_direction =
        normalize(direction + view_direction);

    float amount =
        pow(
            max(dot(normal, halfway_direction), 0.0),
            shininess
        );

    return lightColor *
           amount *
           lightIntensity *
           specularStrength *
           specularColor;
}

void calculate_point_light(
    PointLight light,
    vec3 normal,
    vec3 view_direction,
    out vec3 diffuse,
    out vec3 specular
)
{
    vec3 to_light =
        light.position - fragmentPosition;

    float distance_to_light =
        length(to_light);

    vec3 direction =
        normalize(to_light);

    float diffuse_amount =
        max(dot(normal, direction), 0.0);

    float attenuation =
        1.0 /
        (
            light.constantAttenuation +
            light.linearAttenuation * distance_to_light +
            light.quadraticAttenuation *
                distance_to_light *
                distance_to_light
        );

    diffuse =
        light.color *
        light.intensity *
        diffuse_amount *
        attenuation;

    vec3 halfway_direction =
        normalize(direction + view_direction);

    float specular_amount =
        pow(
            max(dot(normal, halfway_direction), 0.0),
            shininess
        );

    specular =
        light.color *
        specular_amount *
        light.intensity *
        specularStrength *
        specularColor *
        attenuation;
}

void main()
{
    vec3 normal =
        normalize(fragmentNormal);

    vec3 view_direction =
        normalize(viewPosition - fragmentPosition);

    vec3 total_diffuse =
        calculate_directional_diffuse(normal);

    vec3 total_specular =
        calculate_directional_specular(
            normal,
            view_direction
        );

    for (int i = 0; i < MAX_POINT_LIGHTS; i++)
    {
        if (i >= pointLightCount)
        {
            break;
        }

        vec3 point_diffuse;
        vec3 point_specular;

        calculate_point_light(
            pointLights[i],
            normal,
            view_direction,
            point_diffuse,
            point_specular
        );

        total_diffuse += point_diffuse;
        total_specular += point_specular;
    }

    vec3 ambient_light =
        ambientLightColor * ambientColor;

    vec3 base_color =
        diffuseColor;

    if (hasDiffuseTexture != 0)
    {
        base_color =
            texture(diffuseTexture, vertexUV).rgb;
    }

    vec3 final_rgb =
        base_color *
        (ambient_light + total_diffuse)
        + total_specular;

    finalColor =
        vec4(final_rgb, 1.0);
}