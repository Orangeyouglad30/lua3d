--Libraries
local Vector3d = require("math/vector3d")

--Constants

--Dynamics

--Functions
local function isCFrame(cframe)
    if type(cframe) ~= "table" then return end
    if not cframe.__type then return end
    if cframe.__type ~= "CFrame" then return end
    return true
end

--Constructors
local CFrame = {}
CFrame.__index = CFrame
CFrame.__type = "CFrame"

function CFrame.new(arg1,arg2,arg3,arg4,arg5,arg6)
    local self = setmetatable({},CFrame)

    local arg1 = arg1 or 0
    local arg2 = arg2 or 0
    local arg3 = arg3 or 0
    local arg4 = arg4 or 0
    local arg5 = arg5 or 0
    local arg6 = arg6 or 0

    if type(arg1) == "number" and type(arg2) == "number" and type(arg3) == "number" then --if arg1,arg2, and arg3 are x, y, and z respectively
        self.position = Vector3d.new(arg1,arg2,arg3)
        self.rotation = Vector3d.new(arg4,arg5,arg6)
    elseif type(arg1) == "table" and arg1.__type and arg1.__type == "Vector3d" then --arg1 is a vector3d
        if type(arg2) == "table" and arg2.__type and arg2.__type == "Vector3d" then --if arg1 and arg2 are both vector3d
            self.position = arg1
            self.rotation = arg2
        else --if just arg1 is a vector3d
            self.position = arg1
            self.rotation = Vector3d.new(0,0,0)
        end
    end

    return self
end

function CFrame.lookAt(position,looking_at)
    local self = setmetatable({},CFrame)

    self.position = position
    self.rotation = Vector3d.fromDirection(looking_at - position)

    return self
end

function CFrame.lookInDirection(position,direction)
    local self = setmetatable({},CFrame)

    self.position = position
    self.rotation = Vector3d.fromDirection(direction)
    
    return self
end

--Methods
function CFrame:get_position()
    return self.position
end

function CFrame:get_rotation()
    return self.rotation
end

function CFrame:get_direction()
    return Vector3d.fromRotation(self.rotation)
end

function CFrame:get_forward()
    local yaw,pitch = self.rotation.y,self.rotation.x

    local forward = Vector3d.new(
        -math.sin(yaw) * math.cos(pitch),
        math.sin(pitch),
        -math.cos(yaw) * math.cos(pitch)
    ):Unit()

    return forward
end

function CFrame:get_right()
    local yaw,pitch = self.rotation.y,self.rotation.x

    local forward = Vector3d.new(
        -math.sin(yaw) * math.cos(pitch),
        math.sin(pitch),
        -math.cos(yaw) * math.cos(pitch)
    ):Unit()

    local world_up = Vector3d.new(0,1,0)
    local right = forward:Cross(world_up):Unit()

    return right
end

function CFrame:get_up()
    local yaw,pitch = self.rotation.y,self.rotation.x

    local forward = Vector3d.new(
        -math.sin(yaw) * math.cos(pitch),
        math.sin(pitch),
        -math.cos(yaw) * math.cos(pitch)
    ):Unit()

    local world_up = Vector3d.new(0,1,0)
    local right = forward:Cross(world_up):Unit()
    local up = right:Cross(forward):Unit()

    return up
end

function CFrame:get_basis()
    local yaw,pitch = self.rotation.y,self.rotation.x

    local forward = Vector3d.new(
        -math.sin(yaw) * math.cos(pitch),
        math.sin(pitch),
        -math.cos(yaw) * math.cos(pitch)
    ):Unit()

    local world_up = Vector3d.new(0,1,0)
    local right = forward:Cross(world_up):Unit()
    local up = right:Cross(forward):Unit()

    return right,up,forward
end

function CFrame.__mul(self,other)
    if not isCFrame(other) then return end

    
end

--Return
return CFrame