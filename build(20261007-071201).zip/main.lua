local Lua3D = require("lua3d")
local Engine = Lua3D.initialize(1280,720)

local CFrame = Lua3D.math.cframe
local Vector3d = Lua3D.math.vector3d

local newScene

function Engine.load()
    newScene = Lua3D.graphics.scene.new()
    newScene.camera.CFrame = CFrame.lookAt(Vector3d.new(0,0,5),Vector3d.new(0,0,0))

    local monkeyMesh = Lua3D.graphics.mesh.fromOBJ("assets/models/blender_monkey.obj")
    local monkeyObject = Lua3D.graphics.object3d.new(monkeyMesh)
    monkeyMesh.position = (Vector3d.new(0,0,0))

    newScene:add("Monkey",monkeyObject)
end

local fpsUpdateEvery = 0.25
local lastUpdate = 0
local frames = 0
local fpsSmoothing = 1
local FPS = 0

function Engine.update(dt)
    FPS = Lua3D.math.common.lerp(FPS,1/dt,fpsSmoothing * dt)

    if Engine.elapsed_time > lastUpdate then
        lastUpdate = lastUpdate + fpsUpdateEvery
        print("FPS: "..math.floor(FPS))
    end

    newScene.objects["Monkey"].rotation = Lua3D.math.vector3d.new(math.sin(Engine.elapsed_time),math.cos(Engine.elapsed_time),2*math.sin(Engine.elapsed_time))

    local strafe_movement = 0
    local forward_movement = 0
    local vertical_movement = 0
end

function Engine.draw()
    Engine:render_scene(newScene)
end

Engine:start()